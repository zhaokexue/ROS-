#ifndef __MBOTLINUXUSART__
#define __MBOTLINUXUSART__
#include <sys.h>	

#define START   0X11
#define FILTER_N 10


extern void USART1_IRQ(void);
extern void USART1_Send_String(u8 *p);
extern void usartSendSpeed(float Left_V, float Right_V,float Angle);
extern unsigned char getCrc8(unsigned char *ptr, unsigned short len);
#endif
